import logo from './logo.svg';
import Demo from './components/Demo';
import Demo1 from './components/Demo1';
import Parent from './components/Parent';
import Sample from './components/sample';
import TodoList from './components/Todolist';
import  { library} from '@fortawesome/fontawesome-svg-core';
import  { faTrash,faPlus,faEdit} from '@fortawesome/free-solid-svg-icons';
library.add(faTrash,faPlus,faEdit);
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>App components</h1>
      <TodoList></TodoList>
    </div>
  );
}

export default App;
