import  React,{Component} from 'react';

export default class Child extends Component{
    render(){
        return(
            <div>
                <h1>React Child component</h1>
                <h3>{this.props.Title}</h3>
            </div>
        );
    }
}