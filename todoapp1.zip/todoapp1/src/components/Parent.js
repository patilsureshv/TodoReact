import  React,{Component} from 'react';
import Child from './child';
import Demo1 from './Demo1';

export default class Parent extends Component{
    render(){
        return(
            <div>
                <h1>React Parent component</h1>
                <Child Title='I m text parent component'></Child>
                <Demo1 Title='I m text parent component Demo comp'></Demo1>
            </div>
        );
    }
}