import  React,{Component} from 'react';

export default class Demo extends Component{
    render(){
        return(
            <div>
                <h1>React Hello world</h1>
            </div>
        );
    }
}

