import  React,{Component} from 'react';

export default class Sample extends Component{
    state ={
        a:'Hello'
    };
    hundleButtonClick=()=>{
        console.log('Inside button click');
        //this.state.a='You press button';
        this.setState({
            a:'You press button'
        });
    };
    render(){
        return(
            <div>
                <h1>{this.state.a}</h1>
                <button type='button' onClick={this.hundleButtonClick}>Click me</button>
      
            </div>
        );
    }
}