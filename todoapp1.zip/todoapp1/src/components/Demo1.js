import React from "react";

/* function Demo1(){
    return(
        <div>
            <h1>hello from function component</h1>
        </div>
    );
} */
const Demo1 = (props) => {
    return(
        <div>
            <h1>hello from function component</h1>
            <h2>{props.Title}</h2>
        </div>
    );
}
export default Demo1;